﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerBag : MonoBehaviour {

    public GameObject BodyInventory;

	// Update is called once per frame
	void Update () {
        if (Input.GetKeyDown(KeyCode.Tab))
        {
            if(BodyInventory.activeInHierarchy == true)
            {
                BodyInventory.SetActive(false);
            }
            else
            {
                BodyInventory.SetActive(true);
            }
        }
	}
}
