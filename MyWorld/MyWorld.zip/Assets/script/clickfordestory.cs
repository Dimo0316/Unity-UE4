﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class clickfordestory : MonoBehaviour {

	void OnMouseDown()
    {
        Destroy(this.gameObject);
    }
}
